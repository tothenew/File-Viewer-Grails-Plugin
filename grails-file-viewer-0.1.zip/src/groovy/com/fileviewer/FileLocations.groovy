package com.fileviewer

/**
 * Created by IntelliJ IDEA.
 * User: himanshu
 * Date: 7 Sep, 2010
 * Time: 6:24:59 PM
 * To change this template use File | Settings | File Templates.
 */
class FileLocations {
	List<String> locations
    Integer linesCount
}
