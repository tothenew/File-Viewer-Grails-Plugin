package org.grails.plugins.fileviewer

/**
 * @author Himanshu Seth (himanshu@intelligrape.com)
 * @author Fabien Benichou (fabien.benichou@gmail.com)
 */

class FileLocations {
	List<String> locations
    Integer linesCount
}
